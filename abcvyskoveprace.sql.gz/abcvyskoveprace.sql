-- Adminer 4.2.4 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `acl`;
CREATE TABLE `acl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `privilege_id` int(11) DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL,
  `access` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `privilege_id` (`privilege_id`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `acl_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `acl_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `acl_ibfk_2` FOREIGN KEY (`privilege_id`) REFERENCES `acl_privileges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `acl_ibfk_3` FOREIGN KEY (`resource_id`) REFERENCES `acl_resources` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `acl` (`id`, `role_id`, `privilege_id`, `resource_id`, `access`) VALUES
(48,	29,	6,	29,	1),
(51,	29,	6,	27,	1),
(53,	29,	6,	24,	1),
(55,	30,	6,	30,	1),
(56,	29,	6,	31,	1),
(57,	30,	6,	32,	1),
(58,	35,	6,	32,	1),
(59,	35,	6,	31,	1),
(60,	35,	6,	27,	1);

DROP TABLE IF EXISTS `acl_privileges`;
CREATE TABLE `acl_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `comment` varchar(250) CHARACTER SET utf8 COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `acl_privileges` (`id`, `key_name`, `name`, `comment`) VALUES
(6,	'edit',	'edit',	'Editovanie');

DROP TABLE IF EXISTS `acl_resources`;
CREATE TABLE `acl_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `key_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `comment` varchar(250) CHARACTER SET utf8 COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `acl_resources_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `acl_resources` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `acl_resources` (`id`, `parent_id`, `key_name`, `name`, `comment`) VALUES
(24,	NULL,	'backend',	'Backend',	'Prihlasenie do backendu'),
(25,	NULL,	'generate_file',	'generate_file',	'umozni pristup do sekcie pre generovanie modelov'),
(27,	NULL,	'spravca_obsahu',	'Správca obsahu',	'Sprava obsdahu'),
(29,	NULL,	'acl',	'ACL',	'Sprava acl'),
(30,	NULL,	'cron',	'Cron',	'Ma pristup do backend-u'),
(31,	NULL,	'spravca_eshopu',	'Spravca eshopu',	'Spravca eshopu'),
(32,	24,	'import_manager',	'Import',	'Import');

DROP TABLE IF EXISTS `acl_roles`;
CREATE TABLE `acl_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `key_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `comment` varchar(250) CHARACTER SET utf8 COLLATE utf8_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `acl_roles_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `acl_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `acl_roles` (`id`, `parent_id`, `key_name`, `name`, `comment`) VALUES
(25,	25,	'mini_admin',	'mini_admin',	''),
(26,	NULL,	'authenticated',	'authenticated',	''),
(29,	NULL,	'admin',	'Admin',	''),
(30,	NULL,	'cron',	'Cron',	'prava pre cron'),
(31,	NULL,	'guest',	'Guest',	''),
(35,	NULL,	'Spravca',	'Spravca',	'Spravca obsahu');

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id_node` int(11) unsigned NOT NULL,
  `add_date` datetime NOT NULL,
  `change_date` datetime DEFAULT NULL,
  `title` text NOT NULL,
  `text` text NOT NULL,
  `template` int(3) unsigned DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `css` text,
  `js` text,
  `comments_enabled` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_node`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id_banner` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('big','medium','small','treeCols','oneCol') NOT NULL DEFAULT 'big',
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id_banner`),
  KEY `order` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id_category` int(11) NOT NULL AUTO_INCREMENT,
  `id_parent` int(11) DEFAULT NULL,
  `sequence` decimal(6,1) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `show_on_bottom` int(1) DEFAULT '0',
  `status` enum('live','invisible','deleted') DEFAULT 'live',
  `left` int(5) DEFAULT NULL,
  `right` int(5) DEFAULT NULL,
  `depth` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_category`),
  KEY `fk_category_category1` (`id_parent`),
  CONSTRAINT `category_ibfk_1` FOREIGN KEY (`id_parent`) REFERENCES `category` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `category_lang`;
CREATE TABLE `category_lang` (
  `id_lang` int(3) NOT NULL,
  `id_category` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `link_rewrite` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `show_in_menu` int(2) DEFAULT '0',
  PRIMARY KEY (`id_lang`,`id_category`),
  KEY `fk_category_lang_lang1` (`id_lang`),
  KEY `fk_category_lang_category1` (`id_category`),
  KEY `id_lang` (`id_lang`),
  KEY `link_rewrite` (`link_rewrite`),
  KEY `name` (`name`),
  CONSTRAINT `category_lang_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `category_product`;
CREATE TABLE `category_product` (
  `id_category` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  PRIMARY KEY (`id_category`,`id_product`),
  KEY `fk_category_has_product_product1` (`id_product`),
  KEY `id_category` (`id_category`),
  CONSTRAINT `category_product_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `category_product_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `product` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id_node` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `address` text,
  `google_text` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `contact` (`id_node`, `title`, `text`, `email_subject`, `email`, `latitude`, `longitude`, `address`, `google_text`) VALUES
(101,	'REALGROUP.SK',	'<p>Prevádzkovateľom servera www.realgroup.sk je spoločnosti Geodézia Záhorie, s.r.o., Skalica, zapísaná v Obch. registri Okresného súdu Trnava, Oddiel Sro, Vložka číslo : 29760/T. Výpis z obchodného registra<a href=\"http://orsr.sk/vypis.asp?ID=239445&amp;SID=7&amp;P=0\" target=\"_blank\"> tu.</a></p>\r\n<p>Fakturačné údaje : </p>\r\n<p>Geodézia Záhorie, s.r.o.</p>\r\n<p>Nám. slobody 98</p>\r\n<p>90901 - Skalica</p>\r\n<p>IČO : 467 430 49</p>\r\n<p>DIČ : 2023 5621 01</p>\r\n<p>B.ú.: 2400283176/8330</p>',	'Kontaktný formulár',	'pavolbincik@gmail.com',	'48.8464456',	'17.228986299999974',	'Námestie slobody 98/7, 90901 Skalica, Slovakia',	''),
(122,	'Náš partner pre výrobu tlačových  produktov je print24',	'',	'',	'',	'',	'',	'',	''),
(135,	'Aquacity Slovakia s.r.o.',	'<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\">\n<h3 class=\"block-title-5\">Sídlo spoločnosti:</h3>\n<p><strong>Aquacity slovakia s.r.o.</strong><br />Ružinovská 28,<br />82103 Bratislava<br /> Slovenská republika</p>\n</div>\n<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\">\n<h3 class=\"block-title-5\">Fakturačné údaje:</h3>\n<p><strong>Aquacity slovakia s.r.o.</strong><br />Ružinovská 28,<br /> <strong>IČO:</strong> <span>44268343</span><br /> <strong>DIČ:</strong> <span>2022660178</span><br /><br /> Zapísaná v obchodnom registri Okresného súdu Bratislava I, Vložka číslo: 23892/B (<a title=\"stiahnuť výpis z obchodného registra\" href=\"#\">stiahnuť výpis z obchodného registra</a>)</p>\n</div>\n<div style=\"clear: both;\"> </div>\n<hr />\n<div style=\"clear: both;\"> </div>\n<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\">\n<h3 class=\"block-title-5\">kontaktné údaje:</h3>\n<p><strong>Telefón:</strong> +123123123<br /> <strong>Fax:</strong> +23423423<br /> <strong>e-mail:</strong> <a title=\"info@zoochovatelskepotreby.sk\" href=\"mailto:info@zoochovatelskepotreby.sk\">info@zoochovatelskepotreby.sk</a><br /> <strong>web:</strong> <a title=\"www.Aquacity slovakia.sk\" href=\"http://www.Aquacity slovakia.sk/\">www.Aquacity slovakia.sk</a></p>\n</div>\n<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-12\">\n<h3 class=\"block-title-5\">Bankové spojenia:</h3>\n<p><br /><strong>Tatra Banka a.s.</strong><br /> <strong>číslo účtu:</strong> 2623555271 / 1100<br /> <strong>IBAN:</strong> SK25 1100 0000 0026 2355 5271<br /> <strong>SWIFT:</strong> TATRSKBX</p>\n</div>',	'Kontaktný formulár',	'info@zoochovatelskepotreby.sk',	'48.162658',	'17.12227699999994',	'Ľubľanská III, 831 02 Bratislava, Slovakia',	'<p><label for=\"frm-form-google_text\">Text do google map</label></p>\n<div> </div>');

DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `id_country` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id_country`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `dashboard`;
CREATE TABLE `dashboard` (
  `id_dashboard` int(11) NOT NULL AUTO_INCREMENT,
  `add_date` datetime NOT NULL,
  `autor` varchar(255) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id_dashboard`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `delivery`;
CREATE TABLE `delivery` (
  `id_delivery` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,3) NOT NULL,
  `sequence` int(3) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(50) NOT NULL,
  PRIMARY KEY (`id_delivery`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `file`;
CREATE TABLE `file` (
  `id_file` int(10) NOT NULL AUTO_INCREMENT,
  `id_file_node` int(10) NOT NULL,
  `src` varchar(255) DEFAULT NULL,
  `ext` char(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sequence` int(5) DEFAULT NULL,
  `params` text COMMENT 'json_atributes',
  `size` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_file`),
  KEY `FKfile467074` (`id_file_node`),
  CONSTRAINT `file_ibfk_1` FOREIGN KEY (`id_file_node`) REFERENCES `file_node` (`id_file_node`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `file_node`;
CREATE TABLE `file_node` (
  `id_file_node` int(10) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(20) DEFAULT NULL,
  `id_module` int(10) DEFAULT NULL,
  `default_file_param` text COMMENT 'json - default params for each file, ',
  PRIMARY KEY (`id_file_node`),
  KEY `type_module` (`module_name`),
  KEY `id_module` (`id_module`),
  KEY `module_name_id_module` (`module_name`,`id_module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id_gallery` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `add_date` datetime NOT NULL,
  `id_user` int(10) NOT NULL,
  PRIMARY KEY (`id_gallery`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `import_placek`;
CREATE TABLE `import_placek` (
  `id_import_placek` int(11) NOT NULL AUTO_INCREMENT,
  `Kod` text NOT NULL,
  `Cena` text NOT NULL,
  `DPH` text NOT NULL,
  `CENA_DPH` text NOT NULL,
  `Sleva` text NOT NULL,
  `Nazev` text NOT NULL,
  `Mj` text NOT NULL,
  `Tree1` text NOT NULL,
  `Tree2` text NOT NULL,
  `Tree3` text NOT NULL,
  `Tree4` text NOT NULL,
  `Popis` text NOT NULL,
  `Podrobnosti` text NOT NULL,
  `Bal1` text NOT NULL,
  `Bal2` text NOT NULL,
  `Bal3` text NOT NULL,
  `Sklad` text NOT NULL,
  `Novinka` text NOT NULL,
  `Vyrobce` text NOT NULL,
  `Nedelitelne_mnozstvi` text NOT NULL,
  `Img` text NOT NULL,
  `EAN` text NOT NULL,
  `EAN2` text NOT NULL,
  `Part_no` text NOT NULL,
  `CenaPoSleve_DPH` text NOT NULL,
  `CenaPoSleve` text NOT NULL,
  `NovyObal` text NOT NULL,
  `Images` text NOT NULL,
  `DMIC` text NOT NULL,
  `DMOC` text NOT NULL,
  PRIMARY KEY (`id_import_placek`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `lang`;
CREATE TABLE `lang` (
  `id_lang` int(3) NOT NULL AUTO_INCREMENT,
  `iso` varchar(4) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `sequence` int(2) NOT NULL,
  `currency` varchar(4) NOT NULL,
  `rate` decimal(8,4) NOT NULL,
  `is_default` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_lang`),
  UNIQUE KEY `iso` (`iso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `lang_translate`;
CREATE TABLE `lang_translate` (
  `id_lang` int(3) NOT NULL,
  `key` varchar(255) NOT NULL,
  `translate` varchar(255) NOT NULL,
  `files` varchar(255) NOT NULL,
  PRIMARY KEY (`id_lang`,`key`),
  KEY `key` (`key`),
  KEY `id_lang_idx` (`id_lang`),
  CONSTRAINT `id_lang` FOREIGN KEY (`id_lang`) REFERENCES `lang` (`id_lang`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `menu_item`;
CREATE TABLE `menu_item` (
  `id_menu_item` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `sequence` smallint(6) unsigned NOT NULL,
  `id_menu` smallint(6) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `date` int(13) NOT NULL DEFAULT '1',
  `status` enum('live','deactivate') NOT NULL DEFAULT 'live',
  `show_comment` int(1) NOT NULL DEFAULT '1',
  `is_home` tinyint(1) DEFAULT NULL,
  `lang` char(3) DEFAULT NULL,
  `depth` tinyint(1) unsigned NOT NULL,
  `left` int(3) unsigned NOT NULL,
  `right` int(3) unsigned NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id_menu_item`),
  KEY `parent` (`parent_id`),
  KEY `id_menu` (`id_menu`),
  KEY `home` (`is_home`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE `newsletter` (
  `id_node` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id_node`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `newsletter_emails`;
CREATE TABLE `newsletter_emails` (
  `id_newsletter_emails` int(11) NOT NULL AUTO_INCREMENT,
  `id_node` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `active` int(1) NOT NULL,
  `adddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unsubscribeHash` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id_newsletter_emails`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `newsletter_sended_msg`;
CREATE TABLE `newsletter_sended_msg` (
  `id_newsletter_sended_msg` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id_newsletter_sended_msg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `node`;
CREATE TABLE `node` (
  `id_node` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(9) unsigned NOT NULL,
  `id_menu_item` int(9) unsigned NOT NULL,
  `id_type_module` int(5) unsigned NOT NULL,
  `position` enum('top','content','content_right') NOT NULL DEFAULT 'content' COMMENT 'zobrazenie na stranke, umiestnenie modulu',
  `sequence` float unsigned NOT NULL,
  `status` enum('not_in_system','live','invisible') NOT NULL DEFAULT 'not_in_system',
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_node`),
  KEY `id_type_modul` (`id_type_module`),
  KEY `id_menu_item` (`id_menu_item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `id_order` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `order_status` int(1) NOT NULL,
  `payment_status` int(1) NOT NULL COMMENT '0->nezaplatene, 1=>zaplatene',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'ci je faktura vymazana',
  `type` int(1) NOT NULL COMMENT '0=>sukromna osova, 1=>podnikatel',
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `paying_vat` int(1) DEFAULT '0',
  `dic` varchar(255) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `iso` varchar(255) NOT NULL,
  `title` int(1) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_method` varchar(100) NOT NULL,
  `delivery_method` varchar(100) NOT NULL,
  `use_delivery_address` int(1) NOT NULL,
  `delivery_address` varchar(255) NOT NULL,
  `delivery_city` varchar(255) NOT NULL,
  `delivery_zip` varchar(255) NOT NULL,
  `delivery_iso` varchar(4) NOT NULL,
  `delivery_phone` varchar(255) NOT NULL,
  `delivery_name` varchar(255) NOT NULL,
  `delivery_surname` varchar(255) NOT NULL,
  `delivery_fax` varchar(255) NOT NULL,
  `delivery_company_name` varchar(255) NOT NULL,
  `delivery_paying_vat` int(1) NOT NULL,
  `total_price` decimal(10,4) NOT NULL COMMENT 'cena je bez DPH',
  `total_price_with_tax` decimal(10,4) NOT NULL,
  `id_lang` int(2) NOT NULL,
  `currency` varchar(4) NOT NULL,
  `rate` decimal(8,4) NOT NULL,
  `text` text,
  `delivery_title` varchar(255) NOT NULL COMMENT 'titulok oznacenia dopravy',
  `delivery_price` decimal(10,4) DEFAULT NULL COMMENT 'cena je bez DPH',
  `delivery_tax` decimal(10,4) NOT NULL,
  `payment_title` varchar(255) NOT NULL COMMENT 'titulok oznacenia platby',
  `payment_price` decimal(10,4) NOT NULL,
  `payment_tax` decimal(10,4) NOT NULL,
  `user_discount` int(3) NOT NULL DEFAULT '0',
  `notice` varchar(255) NOT NULL,
  `agree` int(1) NOT NULL,
  `delivery_terms` int(1) NOT NULL,
  `id_invoice` int(11) DEFAULT NULL,
  `our_invoice_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `order_product`;
CREATE TABLE `order_product` (
  `id_order_product` int(11) NOT NULL AUTO_INCREMENT,
  `id_order` int(11) NOT NULL,
  `id_product_param` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `price` decimal(10,4) NOT NULL,
  `price_with_tax` decimal(10,4) NOT NULL,
  `count` int(3) NOT NULL,
  `tax` decimal(3,1) NOT NULL,
  PRIMARY KEY (`id_order_product`),
  KEY `id_order` (`id_order`),
  CONSTRAINT `order_product_ibfk_1` FOREIGN KEY (`id_order`) REFERENCES `order` (`id_order`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `id_payment` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,3) NOT NULL,
  `sequence` int(3) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_payment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id_product` int(11) NOT NULL AUTO_INCREMENT,
  `id_product_supplier` int(11) DEFAULT NULL,
  `id_product_mark` int(11) DEFAULT NULL,
  `id_vat` int(2) NOT NULL,
  `group_code` varchar(200) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `adddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `home` int(1) NOT NULL DEFAULT '0',
  `news` int(1) NOT NULL DEFAULT '0',
  `our_tip` int(1) NOT NULL,
  `sale` int(1) NOT NULL,
  `sale_percent` decimal(4,2) NOT NULL,
  `available` smallint(1) unsigned DEFAULT '0',
  `product_sequence` int(11) DEFAULT NULL,
  `id_product_template_group` int(11) NOT NULL,
  `status` enum('live','invisible','deleted') NOT NULL DEFAULT 'live',
  PRIMARY KEY (`id_product`),
  KEY `fk_product_product_supplier1` (`id_product_supplier`),
  KEY `adddate` (`adddate`),
  KEY `id_vat` (`id_vat`),
  KEY `id_product_mark` (`id_product_mark`),
  KEY `group_code` (`group_code`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`id_product_mark`) REFERENCES `product_mark` (`id_product_mark`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_alternative`;
CREATE TABLE `product_alternative` (
  `id_product` int(11) NOT NULL,
  `id_product_alternative` int(11) NOT NULL,
  PRIMARY KEY (`id_product`,`id_product_alternative`),
  KEY `id_product` (`id_product`,`id_product_alternative`),
  KEY `id_product_alternative` (`id_product_alternative`),
  CONSTRAINT `product_alternative_ibfk_1` FOREIGN KEY (`id_product`) REFERENCES `product` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_alternative_ibfk_2` FOREIGN KEY (`id_product_alternative`) REFERENCES `product` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_lang`;
CREATE TABLE `product_lang` (
  `id_lang` int(3) NOT NULL,
  `id_product` int(11) NOT NULL,
  `name` varchar(145) DEFAULT NULL,
  `description` text,
  `link_rewrite` varchar(145) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keywords` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `referencies` text,
  `long_description` text NOT NULL,
  KEY `fk_product_lang_product` (`id_product`),
  KEY `fk_product_lang_lang1` (`id_lang`),
  KEY `id_lang` (`id_lang`,`id_product`),
  KEY `link_rewrite` (`link_rewrite`),
  CONSTRAINT `product_lang_ibfk_1` FOREIGN KEY (`id_lang`) REFERENCES `lang` (`id_lang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_lang_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `product` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_mark`;
CREATE TABLE `product_mark` (
  `id_product_mark` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `top` int(1) NOT NULL DEFAULT '0',
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_product_mark`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_param`;
CREATE TABLE `product_param` (
  `id_product_param` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` int(11) DEFAULT NULL,
  `code` varchar(30) NOT NULL,
  `stock` int(5) NOT NULL,
  `sequence` decimal(4,1) NOT NULL,
  `price` decimal(14,5) DEFAULT NULL COMMENT 'cena bez dph',
  `image` varchar(250) DEFAULT NULL,
  `weight` varchar(50) DEFAULT NULL,
  `packing` varchar(10) DEFAULT NULL,
  `unit_of_measure` varchar(10) DEFAULT NULL,
  `connection` varchar(255) DEFAULT NULL,
  `EAN` varchar(255) DEFAULT NULL,
  `capacity` varchar(255) DEFAULT NULL,
  `is_main` int(1) DEFAULT '0',
  `is_on_stock` int(1) DEFAULT '0',
  PRIMARY KEY (`id_product_param`),
  KEY `id_product` (`id_product`),
  CONSTRAINT `product_param_ibfk_1` FOREIGN KEY (`id_product`) REFERENCES `product` (`id_product`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_param_rewrite`;
CREATE TABLE `product_param_rewrite` (
  `id_product_param` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`id_product_param`),
  KEY `slug` (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `product_supplier`;
CREATE TABLE `product_supplier` (
  `id_product_supplier` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id_product_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id_setting` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `date_add` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_setting`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `setting` (`id_setting`, `name`, `value`, `date_add`, `date_upd`) VALUES
(1,	'SHOP_ENABLE',	'1',	'2011-11-20 16:47:09',	'2014-11-25 14:29:32'),
(2,	'SHOW_TAX_FOR_PRODUCT',	'0',	'2011-11-20 16:47:09',	'2014-11-25 14:29:32'),
(36,	'CONDITIONS_CMS_ID',	'102',	'2016-10-22 14:22:44',	'2016-10-22 14:23:37'),
(4,	'CONDITIONS_CMS_PAGE_ID',	'9',	'2011-11-20 18:35:47',	'2014-11-25 14:29:32'),
(7,	'DELIVERY_IS_WITH_TAX',	'1',	'2011-11-20 21:06:46',	'2012-02-27 14:10:26'),
(8,	'DELIVERY_TAX',	'20',	'2011-11-20 21:09:21',	'2014-11-25 14:29:32'),
(23,	'GOOGLE__client_id',	'924141147825-jbclqtdoih1uqttqcrbt4fjmrhfccs16.apps.googleusercontent.com',	'2012-02-17 22:35:17',	'2014-11-25 14:29:32'),
(22,	'GOOGLE__AUTH_ENABLE',	'1',	'2012-02-17 22:35:17',	'2014-11-25 14:29:32'),
(21,	'FACEBOOK__secret',	'00d765dd1134efa212c9d673d94c38bf',	'2012-02-17 16:07:58',	'2014-11-25 14:29:32'),
(20,	'FACEBOOK__appId',	'343659542349792',	'2012-02-17 16:07:58',	'2014-11-25 14:29:32'),
(19,	'FACEBOOK__AUTH_ENABLE',	'1',	'2012-02-17 16:07:58',	'2014-11-25 14:29:32'),
(18,	'HEUREKA__API_KEY',	'',	'2012-02-17 16:07:58',	'2014-11-25 14:29:32'),
(17,	'HEUREKA__ENABLE',	'0',	'2012-02-17 16:07:58',	'2016-10-23 17:40:14'),
(24,	'GOOGLE__client_secret',	'hoYIfFBPYkpeuGwEacK3LNjd',	'2012-02-17 22:35:17',	'2014-11-25 14:29:32'),
(25,	'GOOGLE__application_name',	'Aqua',	'2012-02-17 22:38:15',	'2016-11-22 20:47:56'),
(26,	'GOOGLE__redirect_url',	'https://www.super-zoo.sk/front/authentification/google-log-in/',	'2012-02-17 22:42:41',	'2016-11-22 20:47:56'),
(27,	'footer_for_emails',	'<p>S pozdravom,</p>\n<p>Príjemný deň a pohodlné nakupovanie Vám praje Aquacity slovakia s.r.o.! Informácie o aktuálnych zľavách či akciách nájdete na našom Facebooku </p>\n<p>Aquacity slovakia s.r.o.<br />chovatelské potreby</p>\n<p>mobil: </p>\n<p>e-mail: info@zoochovatelskepotreby.sk </p>\n<p>Predávajúcim a prevádzkovateľom internetového obchodu www.super-zoo.sk je Aquacity slovakia s.r.o., Panská 9 811 01 Bratislava. Zapísaná na Okr. súde Bratislava I, odd. Sro, vl.č.53535/B IČO: 44268343 , DIČ: 2022660178. Sme platcami DPH.</p>\n<p>Bankové spojenie:</p>\n<p>Číslo účtu :</p>\n<p>Pri úhrade použite prosím číslo objednávky ako Variabilný symbol.</p>',	'2012-02-18 08:14:43',	'2016-11-10 19:23:19'),
(28,	'GOOGLE_ANALYTICS__ID',	'UA-1744204-12ss',	'2012-02-20 10:38:49',	'2014-11-25 14:29:32'),
(29,	'ADMIN_INSERT_PRICE_WITH_TAX',	'1',	'2012-02-27 14:16:49',	'2012-02-27 14:16:49'),
(30,	'PAYMENT_TAX',	'20',	'2012-02-27 14:54:19',	'2014-11-25 14:29:32'),
(31,	'SHOW_PRICE_WITH_TAX',	'0',	'2012-03-22 12:59:42',	'2016-11-11 14:23:43'),
(37,	'SUPERFAKTURA_API',	'72b98570bddf5c089867c35f7751eac7',	'2016-12-02 16:26:21',	'2016-12-02 16:26:21'),
(38,	'SUPERFAKTURA_EMAIL',	'info@zoochovatelskepotreby.sk',	'2016-12-02 16:26:21',	'2016-12-02 16:26:21');

DROP TABLE IF EXISTS `slideshow`;
CREATE TABLE `slideshow` (
  `id_node` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `param` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `translation`;
CREATE TABLE `translation` (
  `id_translation` int(11) NOT NULL AUTO_INCREMENT,
  `id_lang` int(3) NOT NULL,
  `key` varchar(255) NOT NULL,
  `translate` text,
  PRIMARY KEY (`id_translation`),
  KEY `id_lang` (`id_lang`),
  CONSTRAINT `translation_ibfk_1` FOREIGN KEY (`id_lang`) REFERENCES `lang` (`id_lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `type_module`;
CREATE TABLE `type_module` (
  `id_type_module` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `service_name` varchar(50) NOT NULL,
  `atributes` varchar(255) DEFAULT NULL,
  `visible_for_user` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_type_module`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id_user` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(64) NOT NULL,
  `password` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `lastvisit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(60) NOT NULL,
  `activate` tinyint(4) NOT NULL,
  `new_password` varchar(250) NOT NULL,
  `discount` int(4) NOT NULL,
  `fbuid` int(15) NOT NULL,
  `google_id` int(15) NOT NULL,
  `newsletter` int(1) NOT NULL,
  `type` int(1) DEFAULT NULL,
  `title` int(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `ico` varchar(20) DEFAULT NULL,
  `paying_vat` int(1) DEFAULT NULL,
  `dic` varchar(50) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `iso` char(3) DEFAULT NULL,
  `delivery_name` varchar(60) DEFAULT NULL,
  `delivery_surname` varchar(60) DEFAULT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  `delivery_city` varchar(60) DEFAULT NULL,
  `delivery_zip` varchar(15) DEFAULT NULL,
  `delivery_phone` varchar(30) DEFAULT NULL,
  `delivery_iso` varchar(4) DEFAULT NULL,
  `use_delivery_address` int(1) DEFAULT NULL,
  `agree` int(1) DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `FKauth_user_189426` (`iso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `login`, `password`, `surname`, `name`, `lastvisit`, `email`, `activate`, `new_password`, `discount`, `fbuid`, `google_id`, `newsletter`, `type`, `title`, `address`, `city`, `zip`, `phone`, `fax`, `ico`, `paying_vat`, `dic`, `company_name`, `iso`, `delivery_name`, `delivery_surname`, `delivery_address`, `delivery_city`, `delivery_zip`, `delivery_phone`, `delivery_iso`, `use_delivery_address`, `agree`) VALUES
(22,	'pavol@bincik.sk',	'240eb8ab22d79a0fb9bb28ff1eb2a28846586b0c',	'Bincik',	'Pavol',	'2017-03-19 20:00:53',	'',	1,	'cdf4e4a544ed397ed44eee59691ee759a8a82a85',	0,	0,	0,	0,	0,	NULL,	'Stefanikova',	'Piestany',	'90901',	'0903564359',	NULL,	'',	0,	'',	'',	'SVK',	'',	'',	'',	'',	'',	'',	'SVK',	0,	1);

DROP TABLE IF EXISTS `user_country`;
CREATE TABLE `user_country` (
  `iso` char(3) NOT NULL,
  `country_name` varchar(100) DEFAULT NULL,
  `active` enum('yes','no') DEFAULT 'no',
  `sequence` int(3) DEFAULT NULL,
  PRIMARY KEY (`iso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user_form`;
CREATE TABLE `user_form` (
  `id_node` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `acl_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(22,	29);

DROP TABLE IF EXISTS `vat`;
CREATE TABLE `vat` (
  `id_vat` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` int(2) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_vat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `vat` (`id_vat`, `name`, `value`, `is_default`) VALUES
(1,	'20%',	20,	1),
(4,	'10%',	10,	0),
(7,	'0%',	0,	0);

DROP TABLE IF EXISTS `widget`;
CREATE TABLE `widget` (
  `id_widget` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `template` text NOT NULL COMMENT 'template, kde sa moze urobit zobrazenie pouzitim premenych z param',
  `sequence` int(6) NOT NULL,
  `adddate` datetime NOT NULL,
  `added` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_widget`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `widget_param`;
CREATE TABLE `widget_param` (
  `id_widget_param` int(11) NOT NULL AUTO_INCREMENT,
  `id_widget` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `type` int(1) NOT NULL COMMENT '0=>text,1=>textarea',
  PRIMARY KEY (`id_widget_param`),
  KEY `id_widget` (`id_widget`),
  CONSTRAINT `widget_param_ibfk_1` FOREIGN KEY (`id_widget`) REFERENCES `widget` (`id_widget`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2017-05-15 20:31:41
